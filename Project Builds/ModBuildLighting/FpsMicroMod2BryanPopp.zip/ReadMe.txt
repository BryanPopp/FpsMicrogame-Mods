For this Microgame Mod I adjusted 2 animations and 3 different forms of lighting along with the skybox. To start, I changed the skybox to a night sky to fit the 
halloween theme as credited below. Accompanying this change is an adjustment of the global directional light to a dark purple so the lighting actually reflects 
the night sky. As for my other light sources I added some to the flames on the candles and the different colored Jack-O-Lanterns. For the animation part I made two simple ones:
the first is a little loop for the flame on the big candle in second room, and my second is jostling the big skull at the end of the hall to make it more creepy.

Night Time Picture(Used as Skybox) wirestock from Freepik.com :https://www.freepik.com/free-photo/beautiful-shining-stars-night-sky_7631083.htm#fromView=search&page=1&position=13&uuid=6af24268-5477-46b9-b429-7c53b86f98a3 
