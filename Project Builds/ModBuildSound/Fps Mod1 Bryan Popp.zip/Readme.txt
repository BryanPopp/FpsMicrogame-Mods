For my first mod of the microgame I added three different models and two sound effects. I went for a bit of a Halloween theme as we are about a month
and a half away at this point. For 3D models I specifically added a Jack-O-lantern, skull, and candles all imported from the asset store. As for my sound 
effects I added a spooky laugh on a trigger when approaching the skull at the end of the level and a new victory noise. Also apart of the requirements
some spooky music to fit the Halloween theme.


Pumpkin by zugzug: https://assetstore.unity.com/packages/3d/props/exterior/halloween-pumpkins-50597
Skull by Ervis Lilaj: https://assetstore.unity.com/packages/3d/characters/low-poly-skull-111786
Candle by Jane Art Studios: https://assetstore.unity.com/packages/3d/props/free-halloween-pumpkin-props-235332
GoodResult Sound Effect from Pixabay: https://pixabay.com/sound-effects/goodresult-82807/
Evil Laugh from Pixabay: https://pixabay.com/sound-effects/evil-laugh-89423/
Background music by Music by Dmitry Taras from Pixabay https://pixabay.com/music/scary-childrens-tunes-creepy-music-box-halloween-music-horror-scary-spooky-dark-ambient-118577/